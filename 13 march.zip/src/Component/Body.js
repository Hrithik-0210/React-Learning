import { useState } from "react";
import { restaurantDetails } from "../constants";
import RestaurantCard from "./RestaurantCard";

const Body = () => {
  // const [text, setNewText] = useState("Hello Everyone");

  // const changeText = () => {
  //   let val = text;
  //   if (val === "Hello Everyone") {
  //     setNewText("Good Morning....");
  //   } else {
  //     setNewText("Hello Everyone  ");
  //   }
  // };

  const [restaurants, setRestaurant] = useState(restaurantDetails);

  const filterRestaurant = () => {
    const filteredRestaurant = restaurants.filter(
      (restaurant) => restaurant.info.avgRating > 4
    );
    setRestaurant(filteredRestaurant);
    console.log(filteredRestaurant);
  };

  return (
    <>
      <button className="filter-btn" onClick={filterRestaurant}>
        filter
      </button>
      <div id="bodySection">
        {restaurants.map((res) => {
          return <RestaurantCard {...res.info} />;
        })}
      </div>
    </>
  );
};
export default Body;
