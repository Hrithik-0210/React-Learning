const Footer = () => {
  return (
    <div id="footer">
      <h4>Footer</h4>
    </div>
  );
};
export default Footer;
