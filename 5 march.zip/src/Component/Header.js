import logo from "../../img/logo.jpg";

const Title = () => {
  return (
    <div id="logoSection">
      <img src={logo} alt="logoImg" id="logoImg" />
      <h1 id="title" key="heading">
        Food Villa
      </h1>
    </div>
  );
};

const HeaderComponent = () => {
  return (
    <div className="nav-items">
      <ul>
        <li>Home</li>
        <li>About</li>
        <li>Contact</li>
        <li>Cart</li>
      </ul>
    </div>
  );
};

const Header = () => {
  return (
    <div id="header">
      <Title />
      <HeaderComponent />
    </div>
  );
};
export default Header;
