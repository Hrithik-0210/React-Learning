import { restaurantDetails } from "../constants";
import RestaurantCard from "./RestaurantCard";

const Body = () => {
  return (
    <>
      <div id="search-container">
        <input
          type="text"
          placeholder="Search"
          className="search-input"
          value=""
        />
        <button className="search-btn">Button</button>
      </div>

      <div id="bodySection">
        {restaurantDetails.map((restaurant) => {
          return <RestaurantCard {...restaurant.info} />;
        })}
      </div>
    </>
  );
};
export default Body;
