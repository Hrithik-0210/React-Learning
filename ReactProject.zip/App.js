import React from "react";
import ReactDOM from "react-dom/client";
import logo from "./img/logo.jpg";

const Title = () => {
  return (
    <div id="logo">
      <img src={logo} alt="logoImg" id="logoImg" />
      <h1 id="title" key="heading">
        Food Villa
      </h1>
    </div>
  );
};
const HeaderComponent = () => {
  return (
    <div className="nav-items">
      <ul>
        <li>Home</li>
        <li>About</li>
        <li>Contact</li>
        <li>Cart</li>
      </ul>
    </div>
  );
};

const Header = () => {
  return (
    <React.Fragment>
      <Title />
      <HeaderComponent />
    </React.Fragment>
  );
};

const Body = () => {
  return (
    <>
      <h4>BODY</h4>
    </>
  );
};
const Footer = () => {
  return (
    <>
      <h4>footer</h4>
    </>
  );
};

const AppLayout = () => {
  return (
    <>
      <Header />
      <Body />
      <Footer />
    </>
  );
};
const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<AppLayout />);
